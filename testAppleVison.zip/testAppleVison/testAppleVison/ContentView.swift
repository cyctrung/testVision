//
//  ContentView.swift
//  testAppleVison
//
//  Created by CycTrung on 1/20/21.
//  Copyright © 2021 CycTrung. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello World")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
